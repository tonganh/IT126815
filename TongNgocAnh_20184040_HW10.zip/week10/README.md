`RUN: make clear && make all`
Change data handle in file nguoidung.txt
`Running server with command: ./server PORT`
`RUNIING client with command: ./server ip_address PORT`
_If you want to connect localhost: use ip_address:127.0.0.1 and port 8080_
_happy codding_
anh.tndev40.
